package org.design_patterns.code_03.strategy;

/**
 * 抽象策略类
 */
public interface Strategy {
    void show();
}
