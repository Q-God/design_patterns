package org.design_patterns.proxy.cglib_proxy;

/**
 *
 */
public interface SellTickets {

    void sell();

}
