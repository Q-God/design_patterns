package org.design_patterns.proxy.jdk_proxy;

/**
 *
 */
public interface SellTickets {

    void sell();

}
