package org.design_patterns.prototype.test;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Test {
    public static void main(String[] args) {
        Map<String, Object> map = new HashMap<>();
        map.put("date", "2021-07-28");

        //1 。Node遍历
        map.forEach((k, v) -> {
            System.out.printf("(%s, %s)\n", k, v);
        });

        //2  entruSet
        Set<Map.Entry<String, Object>> entries = map.entrySet();
        //增强for
        for (Map.Entry<String, Object> entry : entries) {
            System.out.printf("(%s, %s)\n", entry.getKey(), entry.getValue());
        }
        //迭代器
        Iterator<Map.Entry<String, Object>> iterator = entries.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Object> entry = iterator.next();
            System.out.printf("(%s, %s)\n", entry.getKey(), entry.getValue());
        }
        //Stream流 java8
        entries.stream().forEach(
                entry -> {
                    System.out.printf("(%s, %s)\n", entry.getKey(), entry.getValue());
                }
        );
        //3 keyset
        Set<String> strings = map.keySet();
        strings.stream().forEach(key -> {
            System.out.printf("(%s, %s)\n", key, map.get(key));
        });
        //4 iterator
        map.entrySet().iterator().forEachRemaining(entry -> {
            System.out.printf("(%s, %s)\n", entry.getKey(), entry.getValue());
        });

        //没有key
        map.values().stream().forEach(System.out::println);



    }
}
