package org.design_patterns.singleton.demo6;

/**
 * @version v1.0
 * @ClassName: Singleton
 * @Description: 枚举实现方式
 * @Author: Q
 */
public enum Singleton {
    INSTANCE
}
