package org.design_patterns.factory.abstract_factory;

/**
 * 甜品抽象类
 */
public abstract class Dessert {

    public abstract void show();
}
